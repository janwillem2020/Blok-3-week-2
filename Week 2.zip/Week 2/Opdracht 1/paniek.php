<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mad Libs</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=ZCOOL+KuaiLe&display=swap" rel="stylesheet">
</head>
<body>
    <?php 
        $huisdierErr = $persoonErr = $landErr = $verveeldErr = $speelgoedErr = $docentErr = $geldErr = $bezigheidErr = "";
        $error = false;

        if ($_SERVER["REQUEST_METHOD"] == 'POST') { 
            if (empty($_POST["huisdier"])) {
                $huisdierErr = "Deze moet je invullen";
                $error = true;
            } else {
                $huisdier = filter($_POST["huisdier"]);
            }

            if (empty($_POST["persoon"])) {
                $persoonErr = "Deze moet je invullen";
                $error = true;
            } else {
                $persoon = filter($_POST["persoon"]);
            }

            if (empty($_POST["land"])) {
                $landErr = "Deze moet je invullen";
                $error = true;
            } else {
                $land = filter($_POST["land"]);
            }

            if (empty($_POST["verveeld"])) {
                $verveeldErr = "Deze moet je invullen";
                $error = true;
            } else {
                $verveeld = filter($_POST["verveeld"]);
            }

            if (empty($_POST["speelgoed"])) {
                $speelgoedErr = "Deze moet je invullen";
                $error = true;
            } else {
                $speelgoed = filter($_POST["speelgoed"]);
            }

            if (empty($_POST["docent"])) {
                $docentErr = "Deze moet je invullen";
                $error = true;
            } else {
                $docent = filter($_POST["docent"]);
            }

            if (empty($_POST["geld"])) {
                $geldErr = "Deze moet je invullen";
                $error = true;
            } else {
                $geld = filter($_POST["geld"]);
            }

            if (empty($_POST["bezigheid"])) {
                $bezigheidErr = "Deze moet je invullen";
                $error = true;
            } else {
                $bezigheid = filter($_POST["bezigheid"]);
            }
        }

        function filter($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    ?>

    <div class="pagina">
        <h1>Mad Libs</h1>
        <section>
            <div class="opvulling">
                <a href="paniek.php"><h3>Er heerst paniek...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3></a>
                <a href="onkunde.php"><h3>Onkunde</h3></a>
            </div>
            <h2>Er heerst paniek...</h2>
            <?php if ($_SERVER["REQUEST_METHOD"] == 'POST' && $error == false) { ?>

            <p>
                Er heerst paniek in het koningkrijk <?php echo $_POST["land"]; ?>. Koning <?php echo $_POST["docent"]; ?> is ten einde raad en als koning <?php echo $_POST["docent"]; ?> ten einde raad is, dan roept hij zijn ten-einde-raadsheer <?php echo $_POST["persoon"]; ?>.<br><br>
                "<?php echo $_POST["persoon"]; ?>! Het is een ramp! Het is een schande!"<br><br>
                "Sire, Majesteit, Uwe Luidruchtigheid, wat is er aan de hand?"<br><br>
                "Mijn <?php echo $_POST["huisdier"]; ?> is verdwenen! Zo maar, zonder waarschuwing. En ik had net <?php echo $_POST["speelgoed"]; ?> voor hem gekocht!"<br><br>
                "Majesteit, uw <?php echo $_POST["huisdier"]; ?> komt vast vanzelf weer terug"<br><br>
                "Ja, da's leuk en aardig, maar hoe moet ik in de tussentijd <?php echo $_POST["bezigheid"]; ?> leren?"<br><br>
                "Maar Sire, daar kunt u toch uw <?php echo $_POST["geld"]; ?> voor gebruiken?"<br><br>
                "<?php echo $_POST["persoon"]; ?>, je hebt helemaal gelijk! Wat zou ik doen als ik jou niet had."<br><br>
                "<?php echo $_POST["verveeld"]; ?>, Sire."<br><br>
            </p>

            <?php } else { ?>
            <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST" class="grid-container">
                <ul class="vraag">
                    <li>Welk dier zou je nooit als huisdier willen hebben?</li>
                    <li>Wie is de belangrijkste persoon in je leven?</li>
                    <li>In welk land zou je willen wonen</li>
                    <li>Wat doe je als je je verveelt?</li>
                    <li>Met welk speelgoed speelde je als kind het meest?</li>
                    <li>Bij welke docent spijbel je het liefst?</li>
                    <li>Als je €100.000,- had, wat zou je dan kopen?</li>
                    <li>Wat is je favoriete bezigheid?</li>
                </ul> 
                <ul class="input">
                    <li><input name="huisdier" type="text" value=<?php echo $huisdier ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $huisdierErr;?></span></li>
                    <li><input name="persoon" type="text" value=<?php echo $persoon ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $persoonErr;?></span></li>
                    <li><input name="land" type="text" value=<?php echo $land ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $landErr;?></span></li>
                    <li><input name="verveeld" type="text" value=<?php echo $verveeld ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $verveeldErr;?></span></li>
                    <li><input name="speelgoed" type="text" value=<?php echo $speelgoed ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $speelgoedErr;?></span></li>
                    <li><input name="docent" type="text" value=<?php echo $docent ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $docentErr;?></span></li>
                    <li><input name="geld" type="text" value=<?php echo $geld ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $geldErr;?></span></li>
                    <li><input name="bezigheid" type="text" value=<?php echo $bezigheid ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $bezigheidErr;?></span></li>
                </ul>
                <input class="laatste" type="submit">
            </form>
            <?php } ?>
        </section>
        <footer>
            <p>&copy; Jan Willem van Bochove 2021</p>
        </footer>
    </div>
</body>
</html>