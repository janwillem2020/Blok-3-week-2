<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
        $nameErr = $emailErr = "";
        $error = false;

        if ($_SERVER["REQUEST_METHOD"] == 'POST') { 
            if (empty($_POST["name"])) {
                $nameErr = "Name is required";
                $error = true;
            } else {
                $name = filter($_POST["name"]);
            }

            if (empty($_POST["email"])) {
                $emailErr = "Email is required";
                $error = true;
            } else {
                $email = filter($_POST["email"]);
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $emailErr = "Geen geldige Email";
                    $error = true;
                }
            }
        }

        function filter($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    ?>

    <?php if ($_SERVER["REQUEST_METHOD"] == 'POST' && $error == false) { ?>

    <h2>De ingevulde gegevens zijn: </h2>
    <p>Naam : <?php echo $name; ?></p>
    <p>Email : <?php echo $email; ?></p>

    <?php } else {?>

    <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST">
        <h2>Form</h2>
        Name: <input type="text" name="name" value=<?php echo $name ?>>
        <span style="color: red;" class="error">* <?php echo $nameErr;?></span><br><br>
        E-mail: <input type="text" name="email" value=<?php echo $email ?>>
        <span style="color: red;" class="error">* <?php echo $emailErr;?></span><br><br>
        <input type="submit">
    </form>

    <?php } echo $name;?>
</body>
</html>