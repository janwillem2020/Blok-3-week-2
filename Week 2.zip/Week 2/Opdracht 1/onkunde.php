<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mad Libs</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=ZCOOL+KuaiLe&display=swap" rel="stylesheet">
</head>
<body>
    <?php
        $kunnenErr = $persoonErr = $getalErr = $dingErr = $gEigenschapErr = $sEigenschapErr = $ergsteErr = "";
        $error = false;

        if ($_SERVER["REQUEST_METHOD"] == 'POST') { 
            if (empty($_POST["kunnen"])) {
                $kunnenErr = "Deze moet je invullen";
                $error = true;
            } else {
                $kunnen = filter($_POST["kunnen"]);
            }

            if (empty($_POST["persoon"])) {
                $persoonErr = "Deze moet je invullen";
                $error = true;
            } else {
                $persoon = filter($_POST["persoon"]);
            }

            if (empty($_POST["getal"])) {
                $getalErr = "Deze moet je invullen";
                $error = true;
            } else {
                $getal = filter($_POST["getal"]);
            }

            if (empty($_POST["ding"])) {
                $dingErr = "Deze moet je invullen";
                $error = true;
            } else {
                $ding = filter($_POST["ding"]);
            }

            if (empty($_POST["gEigenschap"])) {
                $gEigenschapErr = "Deze moet je invullen";
                $error = true;
            } else {
                $gEigenschap = filter($_POST["gEigenschap"]);
            }

            if (empty($_POST["sEigenschap"])) {
                $sEigenschapErr = "Deze moet je invullen";
                $error = true;
            } else {
                $sEigenschap = filter($_POST["sEigenschap"]);
            }

            if (empty($_POST["ergste"])) {
                $ergsteErr = "Deze moet je invullen";
                $error = true;
            } else {
                $ergste = filter($_POST["ergste"]);
            }
        }

        function filter($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
    ?>
    <div class="pagina">
        <h1>Mad Libs</h1>
        <section>
            <div class="opvulling">
                <a href="paniek.php"><h3>Er heerst paniek...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3></a>
                <a href="onkunde.php"><h3>Onkunde</h3></a>
            </div>
            <h2>Onkunde</h2>
            <?php if ($_SERVER["REQUEST_METHOD"] == 'POST' && $error == false) { ?>
            
            <p>Er zijn heel veel mensen die niet kunnen <?php echo $_POST["kunnen"]; ?>. Neem nou <?php echo $_POST["persoon"]; ?>. Zelfs met de hulp van een <?php echo $_POST["ding"]; ?> of zelfs <?php echo $_POST["getal"]; ?> kan <?php echo $_POST["persoon"]; ?> niet <?php echo $_POST["kunnen"]; ?>. Dat heeft niet te maken met een gebrek aan <?php echo $_POST["gEigenschap"]; ?>, maar met een te veel aan <?php echo $_POST["sEigenschap"]; ?>. Te veel <?php echo $_POST["sEigenschap"]; ?> leidt tot <?php echo $_POST["ergste"]; ?> en dat is niet goed als je wilt <?php echo $_POST["kunnen"]; ?>. Helaas voor <?php echo $_POST["persoon"]; ?>.</p>

            <?php } else { ?>
            <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="POST" class="grid-container">
                <ul class="vraag">
                    <li>Wat zou je graag willen kunnen?</li>
                    <li>Met welke persoon kun je goed opschieten?</li>
                    <li>Wat is je favoriete getal?</li>
                    <li>Wat heb je altijd bij je als je op vakantie gaat?</li>
                    <li>Wat is je beste persoonlijke eigenschap?</li>
                    <li>Wat is je slechtste persoonlijke eigenschap?</li>
                    <li>Wat is het ergste dat je kan overkomen?</li>
                </ul> 
                <ul class="input">
                    <li><input name="kunnen" type="text" value=<?php echo $kunnen ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $kunnenErr;?></span></li>
                    <li><input name="persoon" type="text" value=<?php echo $persoon ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $persoonErr;?></span></li>
                    <li><input name="getal" type="text" value=<?php echo $getal ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $getalErr;?></span></li>
                    <li><input name="ding" type="text" value=<?php echo $ding ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $dingErr;?></span></li>
                    <li><input name="gEigenschap" type="text" value=<?php echo $gEigenschap ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $gEigenschapErr;?></span></li>
                    <li><input name="sEigenschap" type="text" value=<?php echo $sEigenschap ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $sEigenschapErr;?></span></li>
                    <li><input name="ergste" type="text" value=<?php echo $ergste ?>>&nbsp;<span style="color: red;" class="error">* <?php echo $ergsteErr;?></span></li>
                </ul>
                <input class="laatste" type="submit">
            </form>
            <?php } ?>
        </section>
        <footer>
            <p>&copy; Jan Willem van Bochove 2021</p>
        </footer>
    </div>
</body>
</html>